<?php 
	class notFoundModel extends Mysql
	{
		public function __construct()
		{
			parent::__construct();
		}

	}
 ?>
<main class="content">
    <div class="row">
    <section class="col-10">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>Nombre</th>
                  <th>Tamaño</th>
                  <th>Eliminar</th>
                </tr>
              </thead>
              <tbody>
                <tr class="table-row">
                  <td>Imagen.png</td>
                  <td>500kb</td>
                  <td>X</td>
                </tr>
                <tr class="table-row">
                  <td>Imagen2.png</td>
                  <td>500Kb</td>
                  <td>X</td>
                </tr>
                <tr class="table-row">
                  <td>Imagen3.png</td>
                  <td>500Kb</td>
                  <td>X</td>
                </tr>
              </tbody>
            </table>
    </section>

<aside class="d-flex flex-column justify-content-around col-1  m-2">
        <button class="btn btn-primary">Añadir Imagen</button>
        <button class="btn btn-primary" id="verImg">Ver Imagen</button>
</aside>
    </div>



</main>
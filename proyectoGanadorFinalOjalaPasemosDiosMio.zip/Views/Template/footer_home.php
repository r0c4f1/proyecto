<footer class="footer py-4" id="contact">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-4 text-lg-start">Copyright &copy; Your Website 2023</div>
                    <div class="col-lg-4 my-3 my-lg-0">
                        <a class="btn btn-dark btn-social mx-2" href="https://wa.link/k3t1a8" aria-label="WhatsApp"><i class="fab fa-whatsapp"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://www.instagram.com/viajesucreglobe" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                        <a class="btn btn-dark btn-social mx-2" href="https://www.facebook.com/ViajesSucreglobe" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    </div>
                    <div class="col-lg-4 text-lg-end">
                        <a class="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                        <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>
<!-- Bootstrap core JS-->
        <script src="<?= base_url(); ?>/Assets/js/all.js" crossorigin="anonymous"></script>
        <!-- Core theme JS-->
        <script src="<?= base_url(); ?>/Assets/js/bootstrap.bundle.min.js"></script>
        <script src="<?= base_url(); ?>/Assets/js/scripts.js"></script>
        <script src="<?= base_url(); ?>/Assets/js/sb-forms-0.4.1.js"></script>

        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * -->
        <!-- <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script> -->
    </body>
</html>